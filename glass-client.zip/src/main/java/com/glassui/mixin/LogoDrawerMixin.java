package com.glassui.mixin;

import com.glassui.title.GlassLogo;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.LogoDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LogoDrawer.class)
public abstract class LogoDrawerMixin {

    // 3-argument overload (the title screen normally calls this one)
    @Inject(method = "draw(Lnet/minecraft/client/gui/DrawContext;IF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassui$logo3(DrawContext ctx, int screenWidth, float alpha, CallbackInfo ci) {
        GlassLogo.draw(ctx, screenWidth, alpha, 30);
        ci.cancel();
    }

    // 4-argument overload with an explicit y
    @Inject(method = "draw(Lnet/minecraft/client/gui/DrawContext;IFI)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassui$logo4(DrawContext ctx, int screenWidth, float alpha, int y, CallbackInfo ci) {
        GlassLogo.draw(ctx, screenWidth, alpha, y);
        ci.cancel();
    }
}
