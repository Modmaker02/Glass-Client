package com.glassui.mixin;

import com.glassui.sneak.SneakLock;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {

    @Inject(method = "tick", at = @At("TAIL"))
    private void glassui$sneakLock(CallbackInfo ci) {
        if (SneakLock.isLatched()) {
            PlayerInput p = this.playerInput;
            this.playerInput = new PlayerInput(p.forward(), p.backward(), p.left(), p.right(), p.jump(), true, p.sprint());
        }
    }
}
