package com.glassui.mixin;

import com.glassui.stats.StatsHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla sidebar scoreboard while the glass stats panel is on (/glassstats toggles it). */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    // the method that draws one objective (exists in all recent versions)
    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void glassui$hideSidebar(DrawContext ctx, ScoreboardObjective objective, CallbackInfo ci) {
        if (StatsHud.enabled) ci.cancel();
    }

    // the newer wrapper that looks the objective up itself
    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void glassui$hideSidebar2(DrawContext ctx, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (StatsHud.enabled) ci.cancel();
    }
}
