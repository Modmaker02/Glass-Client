package com.glassui.mixin;

import com.glassui.GlassRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextIconButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClickableWidget.class)
public abstract class ClickableWidgetMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void glassui$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Object self = this;
        if (!(self instanceof ButtonWidget) || self instanceof TextIconButtonWidget) return;

        ClickableWidget w = (ClickableWidget) self;
        if (!w.visible) { ci.cancel(); return; }

        boolean hovered = w.active && mouseX >= w.getX() && mouseY >= w.getY()
                && mouseX < w.getX() + w.getWidth() && mouseY < w.getY() + w.getHeight();

        GlassRenderer.draw(context, w.getX(), w.getY(), w.getWidth(), w.getHeight(), w.active, hovered);

        Text msg = w.getMessage();
        var tr = MinecraftClient.getInstance().textRenderer;
        int avail = w.getWidth() - 8;
        if (tr.getWidth(msg) > avail) {
            int dots = tr.getWidth("..");
            String cut = tr.trimToWidth(msg.getString(), Math.max(0, avail - dots));
            msg = Text.literal(cut + "..").setStyle(msg.getStyle());
        }
        int color = w.active ? 0xFFFFFFFF : 0xFFA0A0A0;
        int ty = w.getY() + (w.getHeight() - 8) / 2;
        context.drawCenteredTextWithShadow(tr, msg, w.getX() + w.getWidth() / 2, ty, color);

        ci.cancel();
    }
}
