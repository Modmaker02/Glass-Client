package com.glassui.mixin;

import com.glassui.GlassRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextIconButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Language;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClickableWidget.class)
public abstract class ClickableWidgetMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void glassui$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Object self = this;
        if (!(self instanceof ButtonWidget) || self instanceof TextIconButtonWidget) return;

        ClickableWidget w = (ClickableWidget) self;
        if (!w.visible) { ci.cancel(); return; }

        int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
        boolean hovered = w.active && mouseX >= x && mouseY >= y && mouseX < x + bw && mouseY < y + bh;
        GlassRenderer.draw(context, x, y, bw, bh, w.active, hovered);

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        Text msg = w.getMessage();
        int color = w.active ? 0xFFFFFFFF : 0xFFA0A0A0;
        int cx = x + bw / 2;
        int ty = y + (bh - 8) / 2;
        int avail = bw - 8;
        int textW = tr.getWidth(msg);

        if (textW <= avail) {
            // fits: draw exactly like vanilla (keeps colors, icons, fonts)
            context.drawCenteredTextWithShadow(tr, msg, cx, ty, color);
        } else if (bw < 48) {
            // tiny button: just clip, never turn it into ".."
            context.enableScissor(x + 2, y, x + bw - 2, y + bh);
            context.drawCenteredTextWithShadow(tr, msg, cx, ty, color);
            context.disableScissor();
        } else {
            // too long: cut and add ".." while keeping the text's own colors/styles
            int dots = tr.getWidth("..");
            StringVisitable cut = tr.trimToWidth(msg, Math.max(0, avail - dots));
            OrderedText ot = Language.getInstance().reorder(
                    StringVisitable.concat(cut, StringVisitable.styled("..", msg.getStyle())));
            context.drawText(tr, ot, cx - tr.getWidth(ot) / 2, ty, color, true);
        }

        ci.cancel();
    }
}
