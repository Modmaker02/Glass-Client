package com.glassui.payment;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.entity.player.SkinTextures;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Player heads. The real 8x8 face (+hat layer) is downloaded once from Mojang and saved to
 * config/paymenthistory_heads.json, so heads stay accurate even for players who are offline.
 */
public final class Skins {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, int[]> HEADS = new ConcurrentHashMap<>();
    private static final Set<String> PENDING = ConcurrentHashMap.newKeySet();
    private static final Map<String, Long> FAILED = new ConcurrentHashMap<>();
    private static final Map<String, SkinTextures> LIVE = new HashMap<>();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "glassclient-skins");
        t.setDaemon(true);
        return t;
    });

    static {
        loadHeads();
    }

    private Skins() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("paymenthistory_heads.json");
    }

    // ------------------------------------------------------------------ storage

    private static void loadHeads() {
        try {
            Path p = path();
            if (!Files.exists(p)) return;
            JsonObject root = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            if (!root.has("heads")) return;
            for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("heads").entrySet()) {
                int[] px = decode(e.getValue().getAsString());
                if (px != null) HEADS.put(e.getKey().toLowerCase(Locale.ROOT), px);
            }
        } catch (Exception ignored) {
        }
    }

    private static synchronized void saveHeads() {
        try {
            JsonObject heads = new JsonObject();
            for (Map.Entry<String, int[]> e : HEADS.entrySet()) heads.addProperty(e.getKey(), encode(e.getValue()));
            JsonObject root = new JsonObject();
            root.add("heads", heads);
            Files.writeString(path(), GSON.toJson(root));
        } catch (Exception ignored) {
        }
    }

    private static String encode(int[] px) {
        StringBuilder sb = new StringBuilder();
        for (int c : px) sb.append(String.format("%06x", c & 0xFFFFFF));
        return sb.toString();
    }

    private static int[] decode(String s) {
        if (s == null || s.length() < 64 * 6) return null;
        int[] px = new int[64];
        for (int i = 0; i < 64; i++) px[i] = Integer.parseInt(s.substring(i * 6, i * 6 + 6), 16);
        return px;
    }

    // ------------------------------------------------------------------ download

    /** Starts (once) a background download of this player's head. Safe to call every frame. */
    public static void request(String name) {
        if (name == null) return;
        String key = name.toLowerCase(Locale.ROOT);
        if (HEADS.containsKey(key) || PENDING.contains(key)) return;
        Long failedAt = FAILED.get(key);
        if (failedAt != null && System.currentTimeMillis() - failedAt < 10 * 60_000L) return;
        if (!name.matches("\\w{1,16}")) return;
        PENDING.add(key);
        EXEC.execute(() -> {
            try {
                int[] px = fetch(name);
                if (px != null) {
                    HEADS.put(key, px);
                    saveHeads();
                } else {
                    FAILED.put(key, System.currentTimeMillis());
                }
            } catch (Exception e) {
                FAILED.put(key, System.currentTimeMillis());
            } finally {
                PENDING.remove(key);
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        });
    }

    private static HttpRequest req(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10))
                .header("User-Agent", "GlassClient").GET().build();
    }

    private static int[] fetch(String name) throws Exception {
        HttpResponse<String> r1 = HTTP.send(req("https://api.mojang.com/users/profiles/minecraft/" + name),
                HttpResponse.BodyHandlers.ofString());
        if (r1.statusCode() != 200) return null;
        JsonObject o1 = JsonParser.parseString(r1.body()).getAsJsonObject();
        if (!o1.has("id")) return null;
        String id = o1.get("id").getAsString();

        HttpResponse<String> r2 = HTTP.send(req("https://sessionserver.mojang.com/session/minecraft/profile/" + id),
                HttpResponse.BodyHandlers.ofString());
        if (r2.statusCode() != 200) return null;
        JsonArray props = JsonParser.parseString(r2.body()).getAsJsonObject().getAsJsonArray("properties");
        for (JsonElement pe : props) {
            JsonObject p = pe.getAsJsonObject();
            if (!"textures".equals(p.get("name").getAsString())) continue;
            String json = new String(Base64.getDecoder().decode(p.get("value").getAsString()), StandardCharsets.UTF_8);
            JsonObject tex = JsonParser.parseString(json).getAsJsonObject().getAsJsonObject("textures");
            if (tex == null || !tex.has("SKIN")) return null;
            String url = tex.getAsJsonObject("SKIN").get("url").getAsString().replace("http://", "https://");
            HttpResponse<byte[]> png = HTTP.send(req(url), HttpResponse.BodyHandlers.ofByteArray());
            if (png.statusCode() != 200) return null;
            return headPixels(png.body());
        }
        return null;
    }

    private static int[] headPixels(byte[] bytes) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(bytes));
        try {
            if (img.getWidth() < 48 || img.getHeight() < 16) return null;
            int[] out = new int[64];
            for (int fy = 0; fy < 8; fy++) {
                for (int fx = 0; fx < 8; fx++) {
                    int face = img.getColorArgb(8 + fx, 8 + fy);
                    int hat = img.getColorArgb(40 + fx, 8 + fy);
                    int c = (hat >>> 24) != 0 ? hat : face;
                    out[fy * 8 + fx] = c & 0xFFFFFF;
                }
            }
            return out;
        } finally {
            img.close();
        }
    }

    // ------------------------------------------------------------------ drawing

    private static SkinTextures live(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler != null) {
            PlayerListEntry e = handler.getPlayerListEntry(name);
            if (e != null) LIVE.put(key, e.getSkinTextures());
        }
        return LIVE.get(key);
    }

    /** Draws the player's head (size x size). Real downloaded head first, then live skin, then a grey square. */
    public static void draw(DrawContext ctx, String name, int x, int y, int size) {
        String key = name.toLowerCase(Locale.ROOT);
        int[] px = HEADS.get(key);
        if (px != null) {
            for (int i = 0; i < 64; i++) {
                int fx = i % 8, fy = i / 8;
                ctx.fill(x + fx * size / 8, y + fy * size / 8,
                        x + (fx + 1) * size / 8, y + (fy + 1) * size / 8, 0xFF000000 | px[i]);
            }
            return;
        }
        request(name);
        SkinTextures t = live(name);
        if (t != null) {
            PlayerSkinDrawer.draw(ctx, t, x, y, size);
        } else {
            ctx.fill(x, y, x + size, y + size, 0xFF5A5A5A);
        }
    }
}
