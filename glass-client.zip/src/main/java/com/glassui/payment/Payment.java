package com.glassui.payment;

public record Payment(String name, long amount, long time) {}
