package com.glassui.payment;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class PaymentStore {
    public record Total(String name, long total, int count) {}

    private static final int MAX = 2000;
    private static final List<Payment> LIST = new ArrayList<>(); // newest first, like the PaymentHistory jar

    private PaymentStore() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("paymenthistory.json");
    }

    public static synchronized void load() {
        LIST.clear();
        try {
            Path p = path();
            if (!Files.exists(p)) return;
            JsonObject root = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            if (!root.has("payments")) return;
            for (JsonElement e : root.getAsJsonArray("payments")) {
                try {
                    JsonObject o = e.getAsJsonObject();
                    LIST.add(new Payment(o.get("name").getAsString(), o.get("amount").getAsLong(), o.get("time").getAsLong()));
                } catch (Exception ignored) {
                }
            }
            LIST.sort((a, b) -> Long.compare(b.time(), a.time()));
        } catch (Exception ex) {
            LIST.clear();
        }
    }

    private static void save() {
        try {
            JsonArray arr = new JsonArray();
            for (Payment p : LIST) {
                JsonObject o = new JsonObject();
                o.addProperty("name", p.name());
                o.addProperty("amount", p.amount());
                o.addProperty("time", p.time());
                arr.add(o);
            }
            JsonObject root = new JsonObject();
            root.add("payments", arr);
            Files.writeString(path(), new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) {
        }
    }

    public static synchronized void add(Payment p) {
        LIST.add(0, p);
        while (LIST.size() > MAX) LIST.remove(LIST.size() - 1);
        save();
    }

    public static synchronized void clear() {
        LIST.clear();
        save();
    }

    /** Newest first. */
    public static synchronized List<Payment> latestFirst() {
        return Collections.unmodifiableList(new ArrayList<>(LIST));
    }

    public static synchronized List<Total> totals() {
        Map<String, long[]> sums = new HashMap<>();
        Map<String, String> names = new HashMap<>();
        for (Payment p : LIST) {
            String k = p.name().toLowerCase(Locale.ROOT);
            long[] s = sums.computeIfAbsent(k, x -> new long[2]);
            s[0] += p.amount();
            s[1] += 1;
            names.put(k, p.name());
        }
        List<Total> out = new ArrayList<>();
        for (Map.Entry<String, long[]> e : sums.entrySet()) {
            out.add(new Total(names.get(e.getKey()), e.getValue()[0], (int) e.getValue()[1]));
        }
        out.sort((a, b) -> Long.compare(b.total(), a.total()));
        return out;
    }
}
