package com.glassui.payment;

import com.glassui.alert.DonationAlerts;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Only SERVER system messages are inspected (ClientReceiveMessageEvents.GAME).
 * The line must START with the payer's name (only symbols/glyphs may come before it) so a player typing
 * "X paid you $5M" in chat can never match: their own name/rank always comes first in the chat line.
 * Anything may follow the amount as long as it is symbols or [bracketed] tags (e.g. other mods' buttons).
 */
public final class PaymentTracker {
    private static final Logger LOG = LoggerFactory.getLogger("GlassClient");

    private static final Pattern PAID = Pattern.compile(
            "^[^A-Za-z0-9\\[\\]]*(\\.?[A-Za-z0-9_]{3,16}) (?:has )?paid you \\$?([0-9][0-9,]*(?:\\.[0-9]+)?)\\s?([kKmMbBtT]?)"
                    + "(?![A-Za-z0-9])(?:[^A-Za-z0-9\\[]|\\[[^\\]]*\\])*$",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern AMOUNT = Pattern.compile("^\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kKmMbBtT]?)$");

    public static final long ALERT_MIN = 1_000_000L;

    private PaymentTracker() {}

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            try {
                handle(message.getString());
            } catch (Exception e) {
                LOG.warn("Payment handling failed", e);
            }
        });
    }

    /** Parses "5M", "250k", "$1,000,000", "1.5B" -> amount, or -1 if invalid. */
    public static long parseAmount(String s) {
        Matcher m = AMOUNT.matcher(s == null ? "" : s.trim());
        if (!m.matches()) return -1;
        return toAmount(m.group(1), m.group(2));
    }

    private static long toAmount(String number, String suffix) {
        double base;
        try {
            base = Double.parseDouble(number.replace(",", ""));
        } catch (NumberFormatException e) {
            return -1;
        }
        double mult = switch (suffix.toLowerCase(Locale.ROOT)) {
            case "k" -> 1e3;
            case "m" -> 1e6;
            case "b" -> 1e9;
            case "t" -> 1e12;
            default -> 1;
        };
        return Math.round(base * mult);
    }

    static void handle(String raw) {
        if (raw == null) return;
        String text = raw.trim();
        Matcher m = PAID.matcher(text);
        if (!m.matches()) {
            if (text.toLowerCase(Locale.ROOT).contains(" paid you ")) {
                LOG.info("Ignored a 'paid you' line that did not match the payment format: {}", text);
            }
            return;
        }

        String name = m.group(1);
        long amount = toAmount(m.group(2), m.group(3));
        if (amount <= 0) return;

        Skins.remember(name);
        PaymentStore.add(new Payment(name, amount, System.currentTimeMillis()));
        if (amount >= ALERT_MIN) DonationAlerts.enqueue(name, amount);
    }
}
