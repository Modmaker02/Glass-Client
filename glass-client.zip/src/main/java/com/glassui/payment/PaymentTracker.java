package com.glassui.payment;

import com.glassui.alert.DonationAlerts;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads server messages like "Name paid you $ 5M" (the $ may be a symbol/glyph, with or without a space).
 * The line must START with the payer's name (only symbols/glyphs may come before it), so a player typing
 * "X paid you $5M" in chat can never match: their own name/rank always comes first in the chat line.
 */
public final class PaymentTracker {
    private static final Logger LOG = LoggerFactory.getLogger("GlassClient");

    // Same core pattern as the PaymentHistory jar:  (\\w{1,16}) paid you \\$\\s*([\\d,]+(?:\\.\\d+)?)\\s*([kKmMbBtT])?
    // plus: only symbols may come before the name (blocks fake chat), and the "$" may be any 1-3 symbol/glyph chars.
    private static final Pattern PAID = Pattern.compile(
            "^[^A-Za-z0-9\\[\\]]*(\\w{1,16})\\s+(?:has\\s+)?paid\\s+you\\s*[^\\w\\s.,]{0,3}\\s*"
                    + "([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kKmMbBtT])?(?![A-Za-z0-9])",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern PAID_WORDS = Pattern.compile("paid\\s+you", Pattern.CASE_INSENSITIVE);
    private static final Pattern AMOUNT = Pattern.compile("^\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kKmMbBtT]?)$");

    public static final long ALERT_MIN = 1_000_000L;

    /** Last "paid you" line that was NOT accepted (for /glassdebug). */
    public static volatile String lastIgnored = "";

    private PaymentTracker() {}

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            safeHandle(message.getString());
        });
        // Some servers deliver system lines through the chat packet. Fake player chat still can't match
        // because the sender's name/rank always starts the line.
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) ->
                safeHandle(message.getString()));
    }

    private static void safeHandle(String raw) {
        try {
            handle(raw);
        } catch (Exception e) {
            LOG.warn("Payment handling failed", e);
        }
    }

    /** Parses "5M", "250k", "$1,000,000", "1.5B" -> amount, or -1 if invalid. */
    public static long parseAmount(String s) {
        Matcher m = AMOUNT.matcher(s == null ? "" : s.trim());
        if (!m.matches()) return -1;
        return toAmount(m.group(1), m.group(2));
    }

    private static long toAmount(String number, String suffix) {
        double base;
        try {
            base = Double.parseDouble(number.replace(",", ""));
        } catch (NumberFormatException e) {
            return -1;
        }
        double mult = switch (suffix.toLowerCase(Locale.ROOT)) {
            case "k" -> 1e3;
            case "m" -> 1e6;
            case "b" -> 1e9;
            case "t" -> 1e12;
            default -> 1;
        };
        return Math.round(base * mult);
    }

    static void handle(String raw) {
        if (raw == null) return;
        String text = raw.replace('\u00A0', ' ').replaceAll("[\\u200B-\\u200F\\u2060\\uFEFF]", "").trim();
        Matcher m = PAID.matcher(text);
        if (!m.find()) {
            if (PAID_WORDS.matcher(text).find()) {
                lastIgnored = text;
                LOG.info("Ignored a 'paid you' line that did not match the payment format: {}", text);
            }
            return;
        }

        String name = m.group(1);
        long amount = toAmount(m.group(2), m.group(3) == null ? "" : m.group(3));
        if (amount <= 0) return;

        Skins.request(name);
        PaymentStore.add(new Payment(name, amount, System.currentTimeMillis()));
        if (amount >= ALERT_MIN) DonationAlerts.enqueue(name, amount);
    }

    /** Runs the same steps as a real payment (record + alert). Used by /glassadd. */
    public static void simulate(String name, long amount) {
        Skins.request(name);
        PaymentStore.add(new Payment(name, amount, System.currentTimeMillis()));
        if (amount >= ALERT_MIN) DonationAlerts.enqueue(name, amount);
    }

    /** Shows non-ASCII characters as <U+XXXX> so odd symbols in a line can be seen. */
    public static String describe(String s) {
        StringBuilder sb = new StringBuilder();
        s.codePoints().forEach(cp -> {
            if (cp >= 32 && cp < 127) sb.appendCodePoint(cp);
            else sb.append("<U+").append(Integer.toHexString(cp).toUpperCase(Locale.ROOT)).append('>');
        });
        return sb.toString();
    }
}
