package com.glassui;

import com.glassui.alert.DonationAlerts;
import com.glassui.payment.PaymentStore;
import com.glassui.payment.PaymentTracker;
import com.glassui.screen.PaymentHistoryScreen;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class GlassUiClient implements ClientModInitializer {
    private static boolean pWasDown;

    @Override
    public void onInitializeClient() {
        PaymentStore.load();
        PaymentTracker.register();
        DonationAlerts.register();

        // P is polled every tick AND every frame so a quick tap is never missed
        ClientTickEvents.END_CLIENT_TICK.register(GlassUiClient::historyKey);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> historyKey(MinecraftClient.getInstance()));

        // /glasstest <amount>  e.g. /glasstest 5M, /glasstest 60M, /glasstest 150M  (plays the alert, saves nothing)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("glasstest")
                        .then(ClientCommandManager.argument("amount", StringArgumentType.word())
                                .executes(c -> {
                                    long amount = PaymentTracker.parseAmount(StringArgumentType.getString(c, "amount"));
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    if (amount <= 0 || mc.player == null) {
                                        c.getSource().sendFeedback(Text.literal("Use e.g. /glasstest 5M"));
                                        return 0;
                                    }
                                    DonationAlerts.enqueue(mc.player.getName().getString(), amount);
                                    return 1;
                                }))));
    }

    /** P opens / closes the Payment History screen (only when no other screen, e.g. chat, is open). */
    private static void historyKey(MinecraftClient client) {
        if (client == null || client.getWindow() == null) return;
        boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_P) == GLFW.GLFW_PRESS;
        if (down && !pWasDown) {
            if (client.currentScreen == null && client.player != null) {
                client.setScreen(new PaymentHistoryScreen());
            } else if (client.currentScreen instanceof PaymentHistoryScreen) {
                client.currentScreen.close();
            }
        }
        pWasDown = down;
    }
}
