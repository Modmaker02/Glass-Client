package com.glassui;

import com.glassui.alert.DonationAlerts;
import com.glassui.payment.PaymentStore;
import com.glassui.payment.PaymentTracker;
import com.glassui.screen.PaymentHistoryScreen;
import com.glassui.stats.StatsHud;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class GlassUiClient implements ClientModInitializer {
    private static boolean pWasDown;
    private static boolean pendingOpen;

    @Override
    public void onInitializeClient() {
        PaymentStore.load();
        PaymentTracker.register();
        DonationAlerts.register();
        StatsHud.register();

        // P is polled every tick AND every frame so a quick tap is never missed
        ClientTickEvents.END_CLIENT_TICK.register(GlassUiClient::historyKey);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> historyKey(MinecraftClient.getInstance()));

        // /paymenthistory and /payhistory open the screen; "... clear confirm" wipes the history
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(historyCommand("paymenthistory"));
            dispatcher.register(historyCommand("payhistory"));
            dispatcher.register(ClientCommandManager.literal("glasshistory").executes(c -> {
                pendingOpen = true;
                return 1;
            }));
        });

        // /glassadd <amount>  adds a TEST payment from you (saved + alert); /paymenthistory clear confirm removes it
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("glassadd")
                        .then(ClientCommandManager.argument("amount", StringArgumentType.word())
                                .executes(c -> {
                                    long amount = PaymentTracker.parseAmount(StringArgumentType.getString(c, "amount"));
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    if (amount <= 0 || mc.player == null) {
                                        c.getSource().sendFeedback(Text.literal("Use e.g. /glassadd 5M"));
                                        return 0;
                                    }
                                    PaymentTracker.simulate(mc.player.getName().getString(), amount);
                                    return 1;
                                }))));
        // /glassstats  switches between the glass stats panel and the normal server sidebar
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("glassstats").executes(c -> {
                    StatsHud.enabled = !StatsHud.enabled;
                    c.getSource().sendFeedback(Text.literal("Glass stats panel: " + (StatsHud.enabled ? "ON" : "OFF")));
                    return 1;
                })));

        // /glassdebug  shows the last "paid you" line the mod ignored (with hidden symbols visible)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("glassdebug").executes(c -> {
                    String last = PaymentTracker.lastIgnored;
                    c.getSource().sendFeedback(Text.literal(last.isEmpty()
                            ? "No ignored payment line yet."
                            : "Last ignored line: " + PaymentTracker.describe(last)));
                    return 1;
                })));

        // /glasstest <amount>  e.g. /glasstest 5M, /glasstest 60M, /glasstest 150M  (plays the alert, saves nothing)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("glasstest")
                        .then(ClientCommandManager.argument("amount", StringArgumentType.word())
                                .executes(c -> {
                                    long amount = PaymentTracker.parseAmount(StringArgumentType.getString(c, "amount"));
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    if (amount <= 0 || mc.player == null) {
                                        c.getSource().sendFeedback(Text.literal("Use e.g. /glasstest 5M"));
                                        return 0;
                                    }
                                    DonationAlerts.enqueue(mc.player.getName().getString(), amount);
                                    return 1;
                                }))));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> historyCommand(String name) {
        return ClientCommandManager.literal(name)
                .executes(c -> {
                    pendingOpen = true; // opened next tick, after the chat screen has closed
                    return 1;
                })
                .then(ClientCommandManager.literal("clear")
                        .executes(c -> {
                            c.getSource().sendFeedback(Text.literal("Type /" + name + " clear confirm to delete all payment history.")
                                    .formatted(Formatting.YELLOW));
                            return 1;
                        })
                        .then(ClientCommandManager.literal("confirm").executes(c -> {
                            PaymentStore.clear();
                            c.getSource().sendFeedback(Text.literal("Payment history cleared.").formatted(Formatting.GREEN));
                            return 1;
                        })));
    }

    /** P opens / closes the Payment History screen (only when no other screen, e.g. chat, is open). */
    private static void historyKey(MinecraftClient client) {
        if (client == null || client.getWindow() == null) return;
        if (pendingOpen && client.currentScreen == null && client.player != null) {
            pendingOpen = false;
            client.setScreen(new PaymentHistoryScreen());
        }
        boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_P) == GLFW.GLFW_PRESS;
        if (down && !pWasDown) {
            if (client.currentScreen == null && client.player != null) {
                client.setScreen(new PaymentHistoryScreen());
            } else if (client.currentScreen instanceof PaymentHistoryScreen) {
                client.currentScreen.close();
            }
        }
        pWasDown = down;
    }
}
