package com.glassui.sneak;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Press sneak once: sneak stays on, even with chat/menus open.
 * Press sneak twice quickly (double tap): sneak turns off.
 */
public final class SneakLock {
    private static final long DOUBLE_MS = 400;
    private static boolean latched;
    private static boolean prevDown;
    private static long lastPress;

    private SneakLock() {}

    public static boolean isLatched() {
        return latched;
    }

    public static void reset() {
        latched = false;
        prevDown = false;
        lastPress = 0;
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null) {
            reset();
            return;
        }
        if (c.currentScreen != null) {
            prevDown = false;
            return;
        }
        boolean down = c.options.sneakKey.isPressed();
        if (down && !prevDown) {
            long now = System.currentTimeMillis();
            if (!latched) {
                latched = true;
                lastPress = now;
                c.player.sendMessage(Text.literal("Sneak lock: ON"), true);
            } else if (now - lastPress <= DOUBLE_MS) {
                latched = false;
                lastPress = 0;
                c.player.sendMessage(Text.literal("Sneak lock: OFF"), true);
            } else {
                lastPress = now;
            }
        }
        prevDown = down;
    }
}
