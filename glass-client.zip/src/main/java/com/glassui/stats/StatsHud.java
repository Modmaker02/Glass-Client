package com.glassui.stats;

import com.glassui.RoundedDraw;
import com.glassui.payment.Skins;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Replaces the server's sidebar scoreboard (Money, Shards, Kills, Deaths, Playtime ...) with a clear glass panel:
 * your skin head + name on top, then every sidebar line exactly as the server sends it (icons and amounts kept),
 * with the smooth font. Values update in real time because they are read straight from the scoreboard.
 */
public final class StatsHud {
    public static boolean enabled = true;

    private static final int PAD = 6, HEAD = 16, ROW = 13, GAP = 5;

    private StatsHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(StatsHud::render);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;

        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return;

        List<ScoreboardEntry> entries = new ArrayList<>();
        for (ScoreboardEntry e : sb.getScoreboardEntries(obj)) {
            if (!e.hidden()) entries.add(e);
        }
        entries.sort((a, b) -> {
            int c = Integer.compare(b.value(), a.value());
            return c != 0 ? c : String.CASE_INSENSITIVE_ORDER.compare(a.owner(), b.owner());
        });
        if (entries.size() > 15) entries = new ArrayList<>(entries.subList(0, 15));

        TextRenderer tr = mc.textRenderer;
        String myName = mc.player.getName().getString();
        Text nameText = SmoothFont.plain(myName, 0xFFFFFF);

        List<Text> lines = new ArrayList<>();
        // some servers use another title than the player name: keep it as a small first line
        String title = obj.getDisplayName().getString().trim();
        if (!title.isEmpty() && !title.equalsIgnoreCase(myName)) lines.add(SmoothFont.smooth(obj.getDisplayName()));
        for (ScoreboardEntry e : entries) {
            Team team = sb.getScoreHolderTeam(e.owner());
            lines.add(SmoothFont.smooth(Team.decorateName(team, e.name())));
        }

        int width = PAD + HEAD + 6 + tr.getWidth(nameText) + PAD;
        int height = PAD + HEAD + 4 + 1 + 4;
        for (Text line : lines) {
            if (line.getString().isBlank()) {
                height += GAP;
            } else {
                width = Math.max(width, PAD * 2 + tr.getWidth(line));
                height += ROW;
            }
        }
        height += PAD - 2;
        width = Math.max(width, 96);

        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = sw - width - 6;
        int y = Math.max(4, (sh - height) / 2);

        // clear glass: faint dark base for readability + white tint + grey outline
        RoundedDraw.fill(ctx, x, y, width, height, 6, 0x30000000);
        RoundedDraw.fill(ctx, x, y, width, height, 6, 0x22FFFFFF);
        RoundedDraw.ring(ctx, x, y, width, height, 6, 0xB09A9A9A);

        // header: skin head + name
        Skins.draw(ctx, myName, x + PAD, y + PAD, HEAD);
        RoundedDraw.ring(ctx, x + PAD - 1, y + PAD - 1, HEAD + 2, HEAD + 2, 3, 0x88FFFFFF);
        ctx.drawText(tr, nameText, x + PAD + HEAD + 6, y + PAD + (HEAD - 9) / 2 + 1, 0xFFFFFFFF, true);

        int hy = y + PAD + HEAD + 4;
        ctx.fill(x + PAD, hy, x + width - PAD, hy + 1, 0x40FFFFFF);

        int ry = hy + 5;
        for (Text line : lines) {
            if (line.getString().isBlank()) {
                ry += GAP;
                continue;
            }
            ctx.drawText(tr, line, x + PAD, ry, 0xFFFFFFFF, true);
            ry += ROW;
        }
    }
}
