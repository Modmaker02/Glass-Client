package com.glassui.stats;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;
import java.util.Optional;
import java.util.function.Function;

/**
 * Applies the smooth Outfit font (assets/glassui/font/smooth.json) to the plain-text parts of a Text.
 * Non-ASCII characters (the server's icons like the star, sword, clock) keep their own font and colors.
 *
 * Style#withFont changed its parameter type between Minecraft versions, so it is found by reflection on its
 * shape (works with Identifier or with a StyleSpriteSource.Font record). If it can't be found, text is left as is.
 */
public final class SmoothFont {
    private static final Identifier FONT = Identifier.of("glassui", "smooth");
    private static final Function<Style, Style> APPLY = resolve();

    private SmoothFont() {}

    public static boolean available() {
        return APPLY != null;
    }

    private static Function<Style, Style> resolve() {
        try {
            // older API: Style withFont(Identifier)
            for (Method m : Style.class.getMethods()) {
                if (m.getReturnType() == Style.class && m.getParameterCount() == 1 && m.getParameterTypes()[0] == Identifier.class) {
                    return s -> invoke(m, s, FONT);
                }
            }
            // newer API: Style withFont(<interface>) where the interface has a nested record Font(Identifier)
            for (Method m : Style.class.getMethods()) {
                if (m.getReturnType() != Style.class || m.getParameterCount() != 1) continue;
                Class<?> p = m.getParameterTypes()[0];
                if (!p.isInterface()) continue;
                for (Class<?> nested : p.getDeclaredClasses()) {
                    if (!nested.isRecord() || !p.isAssignableFrom(nested)) continue;
                    RecordComponent[] rc = nested.getRecordComponents();
                    if (rc.length != 1 || rc[0].getType() != Identifier.class) continue;
                    Constructor<?> c = nested.getDeclaredConstructor(Identifier.class);
                    Object source = c.newInstance(FONT);
                    return s -> invoke(m, s, source);
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static Style invoke(Method m, Style s, Object arg) {
        try {
            return (Style) m.invoke(s, arg);
        } catch (Throwable t) {
            return s;
        }
    }

    public static Style withFont(Style style) {
        return APPLY == null ? style : APPLY.apply(style);
    }

    /** Plain ASCII text in the smooth font. */
    public static Text plain(String s, int rgb) {
        return Text.literal(s).setStyle(withFont(Style.EMPTY.withColor(rgb)));
    }

    /** Same text, but ASCII runs use the smooth font; icons (non-ASCII) are untouched. */
    public static Text smooth(Text t) {
        if (APPLY == null) return t;
        MutableText out = Text.empty();
        t.<Object>visit((style, s) -> {
            StringBuilder run = new StringBuilder();
            boolean ascii = true;
            int i = 0;
            while (i < s.length()) {
                int cp = s.codePointAt(i);
                i += Character.charCount(cp);
                boolean a = cp < 128;
                if (run.length() > 0 && a != ascii) {
                    flush(out, run, ascii, style);
                }
                ascii = a;
                run.appendCodePoint(cp);
            }
            flush(out, run, ascii, style);
            return Optional.empty();
        }, Style.EMPTY);
        return out;
    }

    private static void flush(MutableText out, StringBuilder run, boolean ascii, Style style) {
        if (run.length() == 0) return;
        out.append(Text.literal(run.toString()).setStyle(ascii ? withFont(style) : style));
        run.setLength(0);
    }
}
