package com.glassui.title;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Draws a big bold "Glass Client" where the Minecraft Java Edition logo normally is. */
public final class GlassLogo {
    private GlassLogo() {}

    public static void draw(DrawContext ctx, int screenWidth, float alpha, int y) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
        if (a < 8) return; // alpha below ~4 would render fully opaque, so skip near-invisible frames

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        MutableText text = Text.literal("Glass Client").formatted(Formatting.BOLD);
        int tw = tr.getWidth(text);
        float s = Math.max(1f, Math.min(4f, (screenWidth - 40f) / tw));

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(screenWidth / 2f, y + 8f);
        m.scale(s, s);
        ctx.drawText(tr, text, -tw / 2, 0, (a << 24) | 0xFFFFFF, true);
        m.popMatrix();
    }
}
