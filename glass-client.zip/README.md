# Glass Client

Fabric 1.21.11 client mod: glass UI, donation alerts, payment history (P), sky title screen.

Build: `gradle build` (jar in build/libs). On GitHub the jar is built under Actions > build > Artifacts.

## Fonts
The stats panel uses Outfit Bold (SIL Open Font License, see src/main/resources/assets/glassui/font/Outfit-OFL.txt).
