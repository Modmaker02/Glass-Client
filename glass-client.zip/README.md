# Glass Client

Fabric 1.21.11 client mod: glass UI, donation alerts, payment history (P), sky title screen.

Build: `gradle build` (jar in build/libs). On GitHub the jar is built under Actions > build > Artifacts.
